<?php 
define("SERVER", "localhost");
define("USER", "barronro_aby");
define("PASSWORD", "AndreaAbigail0506");
define("DB", "barronro_Abi");
?>