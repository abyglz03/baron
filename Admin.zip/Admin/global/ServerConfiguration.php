<?php 
define("SERVER", "localhost");
define("USER", "barronro_aby");
define("PASSWORD", "");
define("DB", "barronro_Abi");
?>